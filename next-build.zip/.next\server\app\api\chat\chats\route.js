var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/chats/route.js")
R.c("server/chunks/[root-of-the-server]__0d9wlv-._.js")
R.c("server/chunks/[root-of-the-server]__15kkquj._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__1s89u0b._.js")
R.c("server/chunks/[root-of-the-server]__01_vifj._.js")
R.c("server/chunks/_next-internal_server_app_api_chat_chats_route_actions_1-vqqto.js")
R.m(22131)
module.exports=R.m(22131).exports
