var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/contacts/groups/route.js")
R.c("server/chunks/[root-of-the-server]__1qpautx._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_18reu2j._.js")
R.c("server/chunks/_next-internal_server_app_api_contacts_groups_route_actions_0b959vy.js")
R.m(45832)
module.exports=R.m(45832).exports
