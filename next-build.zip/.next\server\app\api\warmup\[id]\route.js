var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/warmup/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0y_mwpi._.js")
R.c("server/chunks/[root-of-the-server]__0w_ayqj._.js")
R.c("server/chunks/[root-of-the-server]__07ebq0y._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__0b15jec._.js")
R.c("server/chunks/_next-internal_server_app_api_warmup_[id]_route_actions_0ga4rjq.js")
R.m(49337)
module.exports=R.m(49337).exports
