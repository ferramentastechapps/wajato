module.exports=[21874,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_chatbot_config_route_actions_0_r81ds.js.map