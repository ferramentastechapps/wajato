module.exports=[98850,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_warmup_pools_%5Bid%5D_stats_route_actions_0854cv0.js.map