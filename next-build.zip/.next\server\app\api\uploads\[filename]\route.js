var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/uploads/[filename]/route.js")
R.c("server/chunks/[root-of-the-server]__0a2uel_._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_uploads_[filename]_route_actions_00cd-c1.js")
R.m(10607)
module.exports=R.m(10607).exports
