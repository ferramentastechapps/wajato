module.exports=[54718,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_companies_%5Bid%5D_route_actions_1kqoq9i.js.map