var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/whatsapp/instances/[name]/protection/route.js")
R.c("server/chunks/[root-of-the-server]__0tj47nq._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_18reu2j._.js")
R.c("server/chunks/1oeh_server_app_api_whatsapp_instances_[name]_protection_route_actions_1h1y-89.js")
R.m(34514)
module.exports=R.m(34514).exports
