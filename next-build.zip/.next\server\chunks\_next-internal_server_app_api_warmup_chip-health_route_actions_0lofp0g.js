module.exports=[15487,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_warmup_chip-health_route_actions_0lofp0g.js.map