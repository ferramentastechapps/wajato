var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_215cqm4.js")
R.c("server/chunks/[root-of-the-server]__10ucbxr._.js")
R.c("server/chunks/[root-of-the-server]__01_vifj._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_health_route_actions_1ryftkb.js")
R.m(43007)
module.exports=R.m(43007).exports
