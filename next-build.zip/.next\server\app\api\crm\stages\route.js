var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/crm/stages/route.js")
R.c("server/chunks/[root-of-the-server]__07z2wz5._.js")
R.c("server/chunks/_18reu2j._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_1-pw2v2.js")
R.c("server/chunks/_next-internal_server_app_api_crm_stages_route_actions_1avmm8j.js")
R.m(10247)
module.exports=R.m(10247).exports
