var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/campaigns/route.js")
R.c("server/chunks/[root-of-the-server]__1kp7z0s._.js")
R.c("server/chunks/_18reu2j._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_1-pw2v2.js")
R.c("server/chunks/_next-internal_server_app_api_campaigns_route_actions_1z1l7o3.js")
R.m(1618)
module.exports=R.m(1618).exports
