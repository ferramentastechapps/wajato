var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/google/callback/route.js")
R.c("server/chunks/[root-of-the-server]__13fskev._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_18reu2j._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_google_callback_route_actions_0x6kl3t.js")
R.m(70225)
module.exports=R.m(70225).exports
