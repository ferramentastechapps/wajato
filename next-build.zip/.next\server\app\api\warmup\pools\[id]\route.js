var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/warmup/pools/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0dw57hn._.js")
R.c("server/chunks/[root-of-the-server]__0w_ayqj._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__07ebq0y._.js")
R.c("server/chunks/[root-of-the-server]__0b15jec._.js")
R.c("server/chunks/_next-internal_server_app_api_warmup_pools_[id]_route_actions_0qc_g82.js")
R.m(72714)
module.exports=R.m(72714).exports
