var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/route.js")
R.c("server/chunks/[root-of-the-server]__1_rwljn._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_18reu2j._.js")
R.c("server/chunks/_next-internal_server_app_api_notifications_route_actions_1272ib8.js")
R.m(94483)
module.exports=R.m(94483).exports
