module.exports=[52132,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_warmup_%5Bid%5D_stats_route_actions_03dd2sn.js.map