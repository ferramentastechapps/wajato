var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/metrics/route.js")
R.c("server/chunks/[root-of-the-server]__1-shxqz._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_18reu2j._.js")
R.c("server/chunks/_next-internal_server_app_api_metrics_route_actions_0qn5q3s.js")
R.m(41924)
module.exports=R.m(41924).exports
