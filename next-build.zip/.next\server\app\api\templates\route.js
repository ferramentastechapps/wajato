var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/templates/route.js")
R.c("server/chunks/[root-of-the-server]__0ntg9s8._.js")
R.c("server/chunks/_18reu2j._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_1-pw2v2.js")
R.c("server/chunks/_next-internal_server_app_api_templates_route_actions_1c0yqgf.js")
R.m(69453)
module.exports=R.m(69453).exports
