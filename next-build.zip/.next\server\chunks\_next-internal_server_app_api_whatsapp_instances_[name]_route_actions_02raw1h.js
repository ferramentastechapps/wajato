module.exports=[66472,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_whatsapp_instances_%5Bname%5D_route_actions_02raw1h.js.map