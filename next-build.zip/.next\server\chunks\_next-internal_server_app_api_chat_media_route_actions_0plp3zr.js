module.exports=[72983,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_chat_media_route_actions_0plp3zr.js.map