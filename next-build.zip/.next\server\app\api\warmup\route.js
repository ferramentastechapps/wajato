var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/warmup/route.js")
R.c("server/chunks/[root-of-the-server]__0w_ayqj._.js")
R.c("server/chunks/[root-of-the-server]__0q-gcp9._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__07ebq0y._.js")
R.c("server/chunks/[root-of-the-server]__0b15jec._.js")
R.c("server/chunks/_next-internal_server_app_api_warmup_route_actions_0fqvitr.js")
R.m(31318)
module.exports=R.m(31318).exports
