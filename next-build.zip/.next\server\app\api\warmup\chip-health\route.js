var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/warmup/chip-health/route.js")
R.c("server/chunks/_01bx5ka._.js")
R.c("server/chunks/[root-of-the-server]__10ucbxr._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__01_vifj._.js")
R.c("server/chunks/_18reu2j._.js")
R.c("server/chunks/_next-internal_server_app_api_warmup_chip-health_route_actions_0lofp0g.js")
R.m(87383)
module.exports=R.m(87383).exports
