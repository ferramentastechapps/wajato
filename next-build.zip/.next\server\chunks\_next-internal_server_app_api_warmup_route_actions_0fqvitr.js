module.exports=[60727,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_warmup_route_actions_0fqvitr.js.map