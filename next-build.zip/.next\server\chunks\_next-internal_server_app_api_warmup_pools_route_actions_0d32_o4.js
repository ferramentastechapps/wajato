module.exports=[45434,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_warmup_pools_route_actions_0d32_o4.js.map