var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/warmup/[id]/contact-info/route.js")
R.c("server/chunks/[root-of-the-server]__0d9wlv-._.js")
R.c("server/chunks/[root-of-the-server]__1natp2w._.js")
R.c("server/chunks/[root-of-the-server]__1s89u0b._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__01_vifj._.js")
R.c("server/chunks/_next-internal_server_app_api_warmup_[id]_contact-info_route_actions_14kvw7f.js")
R.m(6232)
module.exports=R.m(6232).exports
