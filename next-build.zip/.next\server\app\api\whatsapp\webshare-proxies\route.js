var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/whatsapp/webshare-proxies/route.js")
R.c("server/chunks/[root-of-the-server]__10_g2zu._.js")
R.c("server/chunks/[root-of-the-server]__1kq8tp0._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__1s89u0b._.js")
R.c("server/chunks/_18reu2j._.js")
R.c("server/chunks/_next-internal_server_app_api_whatsapp_webshare-proxies_route_actions_1mn9kaf.js")
R.m(6087)
module.exports=R.m(6087).exports
