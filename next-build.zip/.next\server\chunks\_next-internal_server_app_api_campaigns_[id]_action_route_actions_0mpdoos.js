module.exports=[18947,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_campaigns_%5Bid%5D_action_route_actions_0mpdoos.js.map