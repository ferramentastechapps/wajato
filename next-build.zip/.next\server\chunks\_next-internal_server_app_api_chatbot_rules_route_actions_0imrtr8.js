module.exports=[71831,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_chatbot_rules_route_actions_0imrtr8.js.map