var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/companies/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1c6urt3._.js")
R.c("server/chunks/_18reu2j._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_1-pw2v2.js")
R.c("server/chunks/_next-internal_server_app_api_companies_[id]_route_actions_1kqoq9i.js")
R.m(9811)
module.exports=R.m(9811).exports
