var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/warmup/pools/route.js")
R.c("server/chunks/[root-of-the-server]__0w_ayqj._.js")
R.c("server/chunks/[root-of-the-server]__0rcp_f0._.js")
R.c("server/chunks/[root-of-the-server]__07ebq0y._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__0b15jec._.js")
R.c("server/chunks/_next-internal_server_app_api_warmup_pools_route_actions_0d32_o4.js")
R.m(4705)
module.exports=R.m(4705).exports
