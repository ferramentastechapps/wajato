module.exports=[17693,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_warmup_%5Bid%5D_route_actions_0ga4rjq.js.map