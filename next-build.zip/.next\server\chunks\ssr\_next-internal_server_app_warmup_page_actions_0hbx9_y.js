module.exports=[78603,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_warmup_page_actions_0hbx9_y.js.map