globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/fAWos-VYHjHItPO16VumT/_buildManifest.js",
    "static/fAWos-VYHjHItPO16VumT/_ssgManifest.js",
    "static/fAWos-VYHjHItPO16VumT/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/01dkdyukbdpqq.js",
    "static/chunks/07-hzktxqjvzd.js",
    "static/chunks/0rg0u3v52x4q2.js",
    "static/chunks/3rxl-jt3pdxgx.js",
    "static/chunks/turbopack-1h9ka9ucimq1c.js"
  ]
};
