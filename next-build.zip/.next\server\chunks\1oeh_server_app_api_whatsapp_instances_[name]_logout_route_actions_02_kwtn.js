module.exports=[67243,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_whatsapp_instances_%5Bname%5D_logout_route_actions_02_kwtn.js.map