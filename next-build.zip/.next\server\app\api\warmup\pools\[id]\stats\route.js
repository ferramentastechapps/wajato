var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/warmup/pools/[id]/stats/route.js")
R.c("server/chunks/[root-of-the-server]__02vvy_n._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_warmup_pools_[id]_stats_route_actions_0854cv0.js")
R.m(99059)
module.exports=R.m(99059).exports
