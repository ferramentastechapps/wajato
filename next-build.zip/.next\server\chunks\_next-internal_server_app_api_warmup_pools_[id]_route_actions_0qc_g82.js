module.exports=[23158,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_warmup_pools_%5Bid%5D_route_actions_0qc_g82.js.map