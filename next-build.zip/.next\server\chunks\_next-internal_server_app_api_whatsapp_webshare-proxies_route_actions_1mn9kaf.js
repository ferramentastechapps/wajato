module.exports=[64333,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_whatsapp_webshare-proxies_route_actions_1mn9kaf.js.map