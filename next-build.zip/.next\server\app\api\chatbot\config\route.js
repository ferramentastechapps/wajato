var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chatbot/config/route.js")
R.c("server/chunks/[root-of-the-server]__1h8un36._.js")
R.c("server/chunks/_18reu2j._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_1-pw2v2.js")
R.c("server/chunks/_next-internal_server_app_api_chatbot_config_route_actions_0_r81ds.js")
R.m(20430)
module.exports=R.m(20430).exports
