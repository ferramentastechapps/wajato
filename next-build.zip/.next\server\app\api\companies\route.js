var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/companies/route.js")
R.c("server/chunks/[root-of-the-server]__0c-2zn8._.js")
R.c("server/chunks/_18reu2j._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_1-pw2v2.js")
R.c("server/chunks/_next-internal_server_app_api_companies_route_actions_1pfh7-b.js")
R.m(42007)
module.exports=R.m(42007).exports
