module.exports=[91925,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_whatsapp_instances_route_actions_1ze79fe.js.map