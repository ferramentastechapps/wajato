module.exports=[38424,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_chat_groups_participants_route_actions_1if2xzv.js.map