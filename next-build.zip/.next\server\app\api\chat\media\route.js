var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/media/route.js")
R.c("server/chunks/[root-of-the-server]__0d9wlv-._.js")
R.c("server/chunks/[root-of-the-server]__0kf30fq._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__1s89u0b._.js")
R.c("server/chunks/[root-of-the-server]__01_vifj._.js")
R.c("server/chunks/_next-internal_server_app_api_chat_media_route_actions_0plp3zr.js")
R.m(19910)
module.exports=R.m(19910).exports
