var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/send/route.js")
R.c("server/chunks/[root-of-the-server]__0d9wlv-._.js")
R.c("server/chunks/[root-of-the-server]__0gdmxz_._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__1s89u0b._.js")
R.c("server/chunks/[root-of-the-server]__01_vifj._.js")
R.c("server/chunks/_next-internal_server_app_api_chat_send_route_actions_05cmw-1.js")
R.m(19593)
module.exports=R.m(19593).exports
