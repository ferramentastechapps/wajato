var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/messages/route.js")
R.c("server/chunks/[root-of-the-server]__0d9wlv-._.js")
R.c("server/chunks/[root-of-the-server]__1ko1a6v._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__1s89u0b._.js")
R.c("server/chunks/[root-of-the-server]__01_vifj._.js")
R.c("server/chunks/_next-internal_server_app_api_chat_messages_route_actions_0j2ylxp.js")
R.m(25564)
module.exports=R.m(25564).exports
