var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/contacts/segments/route.js")
R.c("server/chunks/[root-of-the-server]__02p-wkg._.js")
R.c("server/chunks/_18reu2j._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_1-pw2v2.js")
R.c("server/chunks/_next-internal_server_app_api_contacts_segments_route_actions_16kepmq.js")
R.m(69972)
module.exports=R.m(69972).exports
