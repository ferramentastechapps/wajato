globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [
    "static/development/_buildManifest.js",
    "static/development/_ssgManifest.js",
    "static/development/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": []
};
