module.exports=[4410,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_crm_page_actions_0tvgs4m.js.map