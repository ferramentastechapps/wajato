module.exports=[33697,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_warmup_%5Bid%5D_logs_route_actions_13mk9q5.js.map