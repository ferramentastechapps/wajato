var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/warmup/[id]/logs/route.js")
R.c("server/chunks/[root-of-the-server]__1l-j3fo._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_warmup_[id]_logs_route_actions_13mk9q5.js")
R.m(50051)
module.exports=R.m(50051).exports
