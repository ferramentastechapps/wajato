var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/warmup/[id]/stats/route.js")
R.c("server/chunks/[root-of-the-server]__0e1s1t_._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_warmup_[id]_stats_route_actions_03dd2sn.js")
R.m(9321)
module.exports=R.m(9321).exports
