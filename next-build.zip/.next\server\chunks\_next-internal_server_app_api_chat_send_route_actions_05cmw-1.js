module.exports=[57322,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_chat_send_route_actions_05cmw-1.js.map